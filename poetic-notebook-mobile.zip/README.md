# Poetic Notebook Mobile

A responsive poetry poster app with Firebase integration.